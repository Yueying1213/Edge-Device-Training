#!/usr/bin/env bash


python3 main_fed_noise.py --sigma 1.5 --clip 0.5 --iid --num_users 100 --model bcmlenet --epochs 150 --gpu 3 --frac 0.25 --update-method standard --lr 0.01 > bcmlenet_mnist_sigma_1.5_frac_1.txt&