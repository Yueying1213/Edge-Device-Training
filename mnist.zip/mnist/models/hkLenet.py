import torch.nn as nn
import torch.nn.functional as F
from layer.bcm_conv import BCMConv2d
from layer.bcm_fc import BCMLinear
from layer.hk_conv import HankelConv2d
from layer.hk_fc import HankelLinear
class hkLeNet(nn.Module):
    def __init__(self,block_size=4):
        super(hkLeNet, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, 5, 1)
        # self.conv2 = nn.Conv2d(20, 50, 5, 1)
        # self.conv1 = HankelConv2d(1, 32, 5, block_size)
        self.conv2 = HankelConv2d(32, 64, 5, block_size)
        self.fc1 = HankelLinear(4 * 4 * 64, 512, block_size)
        self.fc2 = HankelLinear(512, 10, block_size)
        # self.fc1 = nn.Linear(4 * 4 * 50, 500)
        # self.fc2 = nn.Linear(500, 10)


    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(x, 2, 2)
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, 2, 2)
        x = x.view(-1, 4 * 4 * 64)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return F.log_softmax(x, dim=1)


