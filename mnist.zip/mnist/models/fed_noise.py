import copy
import torch
from torch import nn
import numpy

# #

def FedAvg_noise(w_global,w_local,args):

    for k in w_global.keys():
        if k.endswith('weight'):
            for i in range(0, len(w_local)):
                w_delta = w_local[i][k] - w_global[k]

                w_delta = w_delta / max(1, torch.norm(w_delta).item() / args.clip)

                w_global[k] += (w_delta) / len(w_local)

            noise = torch.normal(torch.zeros(w_global[k].shape), (args.sigma * args.clip)).to(args.device)

            w_global[k] += (noise) / len(w_local)
        else:
            for i in range(0, len(w_local)):
                w_delta = w_local[i][k] - w_global[k]

                w_global[k] += (w_delta) / len(w_local)




    return w_global

# def FedAvg_noise(w_global,w_local,args):
#     for k in w_global.keys():
#         for i in range(0, len(w_local)):
#             w_delta = w_local[i][k] - w_global[k]
#             w_global[k] += w_delta/len(w_local)
#
#     return w_global
