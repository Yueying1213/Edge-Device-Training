import torch
import numpy as np
import yaml

class ADMM:
    def __init__(self, args, rho=0.01):
        self.init_rho = rho
        self.admm_U = {}
        self.admm_Z = {}
        self.rhos = {}
        self.prune_ratios = None
        self.num_users = args.num_users
        for n in range(self.num_users):
            self.admm_U[n] = {}
            self.admm_Z[n] = {}

    def read_config(self, model, filename):
        if not isinstance(filename, str):
            raise Exception("filename must be a str")
        with open(filename, "r") as stream:
            try:
                raw_dict = yaml.safe_load(stream)
                self.prune_ratios = raw_dict['prune_ratios']
                for (name, W) in model.named_parameters():
                    if name not in self.prune_ratios:
                        continue
                    self.rhos[name] = self.init_rho
            except yaml.YAMLError as exc:
                print(exc)


def weight_pruning(args, weight, prune_ratio):
    weight = weight.cpu().detach().numpy()  # convert cpu tensor to numpy
    percent = prune_ratio * 100
    if (args.sparsity_type == "irregular"):
        weight_temp = np.abs(weight)  # a buffer that holds weights with absolute values
        percentile = np.percentile(weight_temp, percent)  # get a value for this percentitle
        under_threshold = weight_temp < percentile
        above_threshold = weight_temp > percentile
        above_threshold = above_threshold.astype(np.float32)
        # has to convert bool to float32 for numpy-tensor conversion
        weight[under_threshold] = 0
        return torch.from_numpy(above_threshold).cuda(), torch.from_numpy(weight).cuda()
    elif (args.sparsity_type == "block"):
        block_size=8

def admm_initialization(args, admm_settings, model, user_id):
        for name, W in model.named_parameters():
            if name in admm_settings.prune_ratios:
                admm_settings.admm_U[user_id][name] = torch.zeros(W.shape).cuda()  # add U
                _, updated_Z = weight_pruning(args, W, admm_settings.prune_ratios[name])  # Z(k+1) = W(k+1)+U(k)  U(k) is zeros her
                admm_settings.admm_Z[user_id][name] = updated_Z

def update_Z_U(args, model, admm_settings, user_id):
    for name, W in model.named_parameters():
        if name not in admm_settings.prune_ratios:
            continue

        if (args.verbose):
            Z_prev = torch.clone(admm_settings.admm_Z[user_id][name])

        # Z(k+1) = W(k+1)+U[k]
        admm_settings.admm_Z[user_id][name] = W + admm_settings.admm_U[user_id][name]

        # equivalent to Euclidean Projection
        _, new_Z = weight_pruning(args, admm_settings.admm_Z[user_id][name],
                                  admm_settings.prune_ratios[name])
        admm_settings.admm_Z[user_id][name] = new_Z

        if (args.verbose):
            print("at layer {}. W(k+1)-Z(k+1): {}".format(name, torch.sqrt(
                torch.sum((W - admm_settings.admm_Z[user_id][name]) ** 2)).item()))
            print("at layer {}, Z(k+1)-Z(k): {}".format(name, torch.sqrt(
                torch.sum((admm_settings.admm_Z[user_id][name] - Z_prev) ** 2)).item()))
            print("at layer {}, rho(k):{}".format(name, admm_settings.rhos[name]))

        # U(k+1) = W(k+1) - Z(k+1) +U(k)
        admm_settings.admm_U[user_id][name] = W - admm_settings.admm_Z[user_id][name] + admm_settings.admm_U[user_id][name]

def admm_update(args, admm_settings, model, epoch, batch_idx, user_id=None):
    # sometimes the start epoch is not zero. It won't be valid if the start epoch is not 0
    if epoch == 0 and batch_idx == 0:
        if admm_settings.admm_U[user_id]:
            update_Z_U(args, model, admm_settings, user_id)
        else:
            admm_initialization(args, admm_settings, model, user_id) # intialize Z, U variable
        return
    if epoch != 0 and epoch % args.admm_epochs == 0 and batch_idx == 0:
        update_Z_U(args, model, admm_settings, user_id)




def append_admm_loss(admm_settings, ce_loss, model, user_id=None):
    '''
    append admm loss to cross_entropy loss
    Args:
        admm_settings: configuration parameters
        model: instance to the model class
        ce_loss: the cross entropy loss
    Returns:
        admm_loss: show admm regularization loss for each layer
        mixed_loss(scalar): the mixed overall loss

    '''
    admm_loss = {}

    for name, W in model.named_parameters():  ## initialize Z (for both weights and bias)
        if name not in admm_settings.prune_ratios:
            continue
        admm_loss[name] = 0.5 * admm_settings.rhos[name] * (
                torch.norm(W - admm_settings.admm_Z[user_id][name] + admm_settings.admm_U[user_id][name], p=2) ** 2)

    mixed_loss = 0
    mixed_loss += ce_loss
    for k, v in admm_loss.items():
        mixed_loss += v
    return admm_loss, mixed_loss


def admm_adjust_learning_rate(optimizer, epoch, config):
    """ (The pytorch learning rate scheduler)
Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""
    """
    For admm, the learning rate change is periodic.
    When epoch is dividable by admm_epoch, the learning rate is reset
    to the original one, and decay every 3 epoch (as the default 
    admm epoch is 9)

    """
    admm_epoch = config.admm_epoch
    lr = None
    if epoch % admm_epoch == 0:
        lr = config.lr
    else:
        admm_epoch_offset = epoch % admm_epoch

        admm_step = admm_epoch / 3  # roughly every 1/3 admm_epoch.

        lr = config.lr * (0.1 ** (admm_epoch_offset // admm_step))

    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

def masking(args, model, admm_settings):
    masks = {}
    for name, W in model.named_parameters():
        if name in admm_settings.prune_ratios:
            above_threshold, pruned_weight = weight_pruning(args, W, admm_settings.prune_ratios[name])
            W.data = pruned_weight
            masks[name] = above_threshold

    admm_settings.masks = masks