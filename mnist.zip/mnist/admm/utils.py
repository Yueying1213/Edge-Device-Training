def test_sparsity(model):
    """
         test sparsity for every involved layer and the overall compression rate
         """
    layer = 0
    tot_param = 0
    tot_zeros = 0

    for name, param in model.named_parameters():
        if "weight" in name:
            layer += 1
            num_tot = param.detach().cpu().numpy().size
            num_zeros = param.detach().cpu().eq(0).sum().item()
            sparsity = (num_zeros / num_tot) * 100
            density = 100 - sparsity
            tot_param += num_tot
            tot_zeros += num_zeros
            print("{}, {}, density: {:.2f}%, sparsity:{:.2f}%, total: {}, zeros: {}, non-zeros: {} ".format(layer, name,
                                                                                                            density,
                                                                                                            sparsity,
                                                                                                            num_tot,
                                                                                                            num_zeros,
                                                                                                            num_tot - num_zeros))

    print("Total parameters: {}, total zeros: {}, total non-zeros: {}".format(tot_param, tot_zeros,
                                                                              tot_param - tot_zeros))
    print("Total sparsity: {:.4f}, compression rate: {:.4f}".format(tot_zeros / tot_param,
                                                                    tot_param / (tot_param - tot_zeros)))




def count_parameters(model, flag_each_layer=True):
    if flag_each_layer:
        total_n=0
        for name, param in model.named_parameters():
            if param.requires_grad:
                count=param.numel()
                total_n += count
                print("Parameters in {} is {} ".format(name, count))

        print("Total parameters in model is {}".format(total_n))
    else:
        print("Total parameters in model is {}".format(sum(p.numel() for p in model.parameters() if p.requires_grad)))