#!/usr/bin/env bash
export CUDA_VISIBLE_DEVICES=0

#python3 main_fed_bkup.py --model lenet --epochs 50 --gpu 0 --iid --update-method standard --lr 0.01 --save-dir "./checkpoints/standard/"

#python3 main_fed_bkup.py --model lenet --epochs 50 --gpu 0 --iid --update-method direct --lr 0.01 --save-dir "./checkpoints/direct/"

python3 main_fed.py --model lenet --epochs 50 --gpu 0 --iid --update-method admm --lr 0.01 --save-dir "./checkpoints/admm/"