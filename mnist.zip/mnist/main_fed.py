from __future__ import print_function
import os

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import copy
import numpy as np
from torchvision import datasets, transforms
import torch
import sys
from utils.sampling import mnist_iid, mnist_noniid
from utils.options import args_parser
from local.update import LocalUpdate
from local.update_admm import LocalUpdateADMM
from local.update_direct import LocalUpdateDirect
from models.lenet import LeNet
from models.bcmlenet8 import BCMLeNet8
from models.bcmlenet32 import BCMLeNet32
from models.mlp import MLP
from models.fed import FedAvg
from models.fed_noise import FedAvg_noise
from utils.test import test_img
from admm import admm



# parse args
args = args_parser()
print(args)
args.device = torch.device('cuda:{}'.format(args.gpu) if torch.cuda.is_available() and args.gpu != -1 else 'cpu')

def main():
    # load dataset and split users
    trans_mnist = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
    dataset_train = datasets.MNIST('temp/data/mnist/', train=True, download=False, transform=trans_mnist)
    dataset_test = datasets.MNIST('temp/data/mnist/', train=False, download=False, transform=trans_mnist)
    # sample users
    if args.iid:
        dict_users = mnist_iid(dataset_train, args.num_users)
    else:
        dict_users = mnist_noniid(dataset_train, args.num_users)
    img_size = dataset_train[0][0].shape

    # build model

    if args.model == 'lenet':
        net_glob = LeNet().to(args.device)
    elif args.model == "bcmlenet":
        if args.block_size == '8':
            net_glob = BCMLeNet8().to(args.device)
        elif args.block_size == '32':
            net_glob = BCMLeNet32().to(args.device)
        else:
            raise ValueError("Block Size Error!")
    elif args.model == 'mlp':
        len_in = 1
        for x in img_size:
            len_in *= x
        net_glob = MLP(dim_in=len_in, dim_hidden=64, dim_out=args.num_classes).to(args.device)
    else:
        exit('Error: unrecognized model')


    net_glob.train()
    print(net_glob)

    # sys.exit(0)
    # training
    loss_train = []
    best_acc = 0
    acc_list = []
    locals={}

    model_path = os.path.join(args.save_dir, args.save_model_name)
    if args.update_method != 'standard':
        admm_settings=admm.ADMM(args)
        admm_settings.read_config(net_glob, args.config_file)

    print("Use {} update method!!".format(args.update_method))

    for round in range(args.epochs):
        if args.lr_scheduler=="default":
            local_lr=adjust_learning_rate(args, round)
        elif args.lr_scheduler==None:
            local_lr=args.lr
        w_locals, loss_locals = [], []
        m = max(int(args.frac * args.num_users), 1)
        idxs_users = np.random.choice(range(args.num_users), m, replace=False)
        for idx in idxs_users:
            if idx in locals.keys():
                local=locals[idx]
                local.update(net=copy.deepcopy(net_glob).to(args.device))
            else:
                if args.update_method=='standard':
                    local = LocalUpdate(args=args, dataset=dataset_train, idxs=dict_users[idx], net=copy.deepcopy(net_glob).to(args.device))
                elif args.update_method=='admm':
                    local = LocalUpdateADMM(args=args, dataset=dataset_train, idxs=dict_users[idx], net=copy.deepcopy(net_glob).to(args.device), admm_settings=admm_settings, user_id=idx)
                elif args.update_method=='direct':
                    local = LocalUpdateDirect(args=args, dataset=dataset_train, idxs=dict_users[idx], net=copy.deepcopy(net_glob).to(args.device), admm_settings=admm_settings)
                else:
                    raise Exception('Not supported yet! "{}"'.format(args.update_method))
                locals[idx]=local
            local.lr=local_lr
            w, loss = local.train()
            w_locals.append(copy.deepcopy(w))
            loss_locals.append(copy.deepcopy(loss))

        # update global weights
        w_glob = FedAvg(w_locals)

        net_glob.load_state_dict(w_glob)
        # torch.cuda.empty_cache()

        # print loss
        loss_avg = sum(loss_locals) / len(loss_locals)
        print('Round {:3d}, Average loss {:.3f}'.format(round, loss_avg))
        acc_test, loss_test = test_img(net_glob, dataset_test, args)
        if best_acc < acc_test:
            print("Get a new best test accuracy:{:.2f}%\n".format(acc_test))
            model_name = model_path + "_acc_{}".format(best_acc) + ".pt"
            model_new_name = model_path + "_acc_{}".format(acc_test) + ".pt"
            if os.path.isfile(model_name):
                os.remove(model_name)
            torch.save(w_glob, model_new_name)
            best_acc = acc_test
        else:
            print("This testing accuracy: {:.2f}%".format(acc_test))
            print("Current best test accuracy:{:.2f}%\n".format(best_acc))

        acc_list.append(acc_test)

        loss_train.append(loss_avg)

    # plot loss curve
    plt.figure()
    plt.plot(range(len(loss_train)), loss_train)
    plt.ylabel('train_loss')
    plt.savefig(
        './figures/fed_mnist_{}_{}_C{}.png'.format( args.model, args.epochs, args.frac))

    # # testing
    # net_glob.eval()
    # # acc_train, loss_train = test_img(net_glob, dataset_train, args)
    # acc_test, loss_test = test_img(net_glob, dataset_test, args)
    # # print("Training accuracy: {:.2f}".format(acc_train))
    # print("Best model's testing accuracy: {:.2f}".format(max(acc_list)))


def adjust_learning_rate(args, round):
    """Sets the learning rate to the initial LR decayed by 2 every 20 epochs"""
    lr = args.lr * (0.9 ** (round // 15))
    print("learning rate ={}".format(lr))
    return lr

if __name__ == '__main__':
    main()
