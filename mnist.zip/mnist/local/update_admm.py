import torch
from torch import nn, autograd
from torch.utils.data import DataLoader, Dataset
import numpy as np
import random
from admm import admm, utils


class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset
        self.idxs = list(idxs)

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        image, label = self.dataset[self.idxs[item]]
        return image, label


class LocalUpdateADMM(object):
    def __init__(self, args, dataset, idxs, net, admm_settings, user_id):
        self.args = args
        self.lr = args.lr
        self.net = net
        self.loss_func = nn.NLLLoss()
        self.selected_clients = []
        self.ldr_train = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True)
        self.admm_settings = admm_settings
        self.user_id=user_id

    def train(self):
        self.net.train()
        # train and update
        optimizer = torch.optim.SGD(self.net.parameters(), lr=self.lr, momentum=self.args.momentum)

        epoch_loss = []

        for iter in range(self.args.local_ep):
            batch_loss = []
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images, labels = images.to(self.args.device), labels.to(self.args.device)
                self.net.zero_grad()
                log_probs = self.net(images)
                ce_loss = self.loss_func(log_probs, labels)

                admm.admm_update(self.args, self.admm_settings, self.net, iter, batch_idx, self.user_id)  # update Z and U
                admm_loss, mixed_loss = admm.append_admm_loss(self.admm_settings, ce_loss, self.net, self.user_id)  # append admm losss

                mixed_loss.backward()
                optimizer.step()
                if self.args.verbose and batch_idx % 10 == 0:
                    print('Update Epoch: {} [{}/{} ({:.0f}%)]\tCE Loss: {:.6f}\tMixed Loss: {:.6f}'.format(
                        iter, batch_idx * len(images), len(self.ldr_train.dataset),
                              100. * batch_idx / len(self.ldr_train), ce_loss.item(), mixed_loss.item()))
                batch_loss.append(mixed_loss.item())

            epoch_loss.append(sum(batch_loss) / len(batch_loss))

        for name, weight in self.net.named_parameters():
            if "weight" in name:
                # w = weight.cpu().detach().numpy()  # convert cpu tensor to numpy
                _, weight.data = admm.weight_pruning(self.args, weight, self.admm_settings.prune_ratios[name])
        # utils.test_sparsity(self.net)
        return self.net.state_dict(), sum(epoch_loss) / len(epoch_loss)

    def update(self, net):
        self.net = net