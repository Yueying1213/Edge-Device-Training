#!/usr/bin/env bash

python3 main_nn.py --dataset mnist --model lenet --evaluate --resume "mnist__acc_99.08.pt"