from scipy.linalg import hankel
import numpy as np
def block_indx(self, k, rc, cc):
    rc = int((rc + k - 1) // k) * k
    cc = int((cc + k - 1) // k) * k
    #print('rc,cc',rc,cc)
    i = np.arange(0, k, 1).reshape([k, 1])
    j = np.arange(k-1, 2*k-1, 1).reshape([1, k])
    #print('i',i)
    #print('j',j)
    indx = hankel(i,j)
    #print('indx',indx)
    #indx = (indx + k) % k
    #print('indx',indx)
    m = np.tile(indx, [int(rc // k), int(cc // k)])
    #print('rc//k:',rc // k,'cc//k:',cc//k)
    #print('m:',m)
    offset = np.arange(0, rc * cc)
    #print('offset',offset)
    i = (offset // cc) // k
    j = (offset % cc) // k
    #print('i:',i)
    #print('j:',j)
    #print('i * cc + j * k :',i * cc + j * k)
    offset = (i * cc + j * k).reshape([rc, cc])
    #print('offset',offset)
    return m + offset

