import math
import torch
import torch.nn as nn
import torch.nn.init as init
import torch.nn.functional as F
from torch.nn.parameter import Parameter

from scipy.linalg import circulant
import numpy as np
import sys
from scipy.linalg import hankel



# Block Hankel Matrix Linear layer
class HankelLinear(nn.Module):
    def __init__(self, in_features, out_features, block_size, bias=True):
        super(HankelLinear, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.block_size = block_size

        if block_size and block_size <= np.min([out_features, in_features]):
            indx = self.block_indx(block_size, in_features, out_features)
            target_c = in_features * out_features * (2 * block_size - 1) // (block_size * block_size)
            print("you are using FC Block Hankel", block_size)
        else:
            print("sorry, not enough size for partitoning", in_features, out_features)
            # target_c = 2 * np.max([in_features, out_features]) - 1
            # a, b = np.ogrid[0:target_c, 0:-target_c:-1]
            # indx = a + b
            indx = np.arange(0, in_features * out_features).reshape(in_features, out_features)
            raise NotImplementedError("Not use Block Hankel in FC layer")



        print('num_filters_in:{}'.format(in_features))
        print('num_filters_out:{}'.format(out_features))
        # print(np.amax(indx))
        # print(indx)
        target_c = np.amax(indx)+1
        print('target_c:{}'.format(target_c))
        # indx = (indx + target_c) % target_c
        print(indx)
        self.indx = indx[:in_features, :out_features]

        self.vector = Parameter(torch.Tensor(target_c))
        # self.weight = Parameter(torch.Tensor(out_features, in_features))
        if bias:
            self.bias = Parameter(torch.Tensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        # init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        init.normal_(self.vector, std=0.1)
        if self.bias is not None:
            self.bias.data.fill_(0.1)
            # self.bias.data.zero_(0.1)

    def forward(self, input):

        weight = self.vector[self.indx[:]].t()

        return F.linear(input, weight, self.bias)

    # def block_indx(self, k, rc, cc):
    #     rc = int((rc + k - 1) // k) * k
    #     cc = int((cc + k - 1) // k) * k
    #     i = np.arange(0, k, 1).reshape([1, k])
    #     j = np.arange(0, -k, -1).reshape([k, 1])
    #     indx = i + j
    #     indx = (indx + k) % k
    #     m = np.tile(indx, [int(rc // k), int(cc // k)])
    #     offset = np.arange(0, rc * cc)
    #     i = (offset // cc) // k
    #     j = (offset % cc) // k
    #     offset = (i * cc + j * k).reshape([rc, cc])
    #     return m + offset

    def block_indx(self, k, rc, cc):
        rc = int((rc + k - 1) // k) * k
        cc = int((cc + k - 1) // k) * k
        # print('rc,cc',rc,cc)
        i = np.arange(0, k, 1).reshape([k, 1])
        j = np.arange(k - 1, 2 * k - 1, 1).reshape([1, k])
        # print('i',i)
        # print('j',j)
        indx = hankel(i, j)

        m = np.tile(indx, [int(rc // k), int(cc // k)])

        # offset=np.zeros([rc,cc]).astype(np.int)
        start= np.arange(0,rc//k*cc//k*(2*k-1),2*k-1).reshape(rc//k,cc//k)
        start = start.repeat([k], axis=0)
        offset = start.repeat([k], axis=1)
        # for i in range(rc):
        #     for j in range(cc):
        #         offset[i,j] = start[i//k, j//k]

        # print('offset',offset)
        return m + offset


if __name__ == '__main__':
    layer = HankelLinear(8, 8, 3)
    # layer=BCMLinear(9, 6, 10)
