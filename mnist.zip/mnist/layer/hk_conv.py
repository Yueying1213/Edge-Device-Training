import math
import torch
import torch.nn as nn
import torch.nn.init as init
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.nn.modules.utils import _pair
from scipy.linalg import hankel
import numpy as np

# Block Circulant Matrix Convolutional layer
class HankelConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, block_size, stride=1, padding=0, dilation=1, groups=1,
                 bias=True):
        super(HankelConv2d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = _pair(stride)
        self.padding = _pair(padding)
        self.dilation = _pair(dilation)
        self.groups = groups
        self.block_size = block_size

        if block_size and block_size <= np.min([out_channels, in_channels]):
            indx = self.block_indx(block_size, out_channels, in_channels)
            target_c = in_channels * out_channels * (2 * block_size - 1) // (block_size * block_size)
            print("you are using Conv2d BlockCirc, {}".format(block_size))
        else:
            print("sorry, not enough size for partitoning, out_channels: {} in_channels: {} kernel_size: {}".format(
                  out_channels, in_channels, kernel_size))
            # target_c = np.max([in_channels, out_channels])
            # a, b = np.ogrid[0:target_c, 0:-target_c:-1]
            # indx = a + b
            indx =np.arange(0, out_channels* in_channels).reshape(out_channels,in_channels)
            raise NotImplementedError("Not use Block Hankel")

        print('num_filters_in:{}'.format(in_channels))
        print('num_filters_out:{}'.format(out_channels))
        target_c = np.amax(indx) + 1
        print('target_c:{}'.format(target_c))
        print(indx)
        self.indx = indx[:out_channels, :in_channels]

        self.vector = Parameter(torch.Tensor(target_c, kernel_size * kernel_size))
        # self.weight = Parameter(torch.Tensor(out_features, in_features))

        if bias:
            self.bias = Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        # init.kaiming_uniform_(self.vector, a=math.sqrt(5))
        n=self.kernel_size*self.kernel_size*self.out_channels
        init.normal_(self.vector, std=math.sqrt(2.0 / n))
        if self.bias is not None:
            fan_in = self.out_channels
            bound = 1 / math.sqrt(fan_in)
            init.uniform_(self.bias, -bound, bound)

    def forward(self, input):

        weight = self.vector[self.indx[:],:].view(self.out_channels, self.in_channels // self.groups,
                                                self.kernel_size, self.kernel_size)
        # weights = tf.reshape(tf.transpose(tf.gather(weights, indx), [2, 1, 0]),
        #                      [int(kernel_h), int(kernel_w), int(num_filters_in), int(num_filters_out)])

        return F.conv2d(input, weight, self.bias, self.stride,
                        self.padding, self.dilation, self.groups)

    # def block_indx(self, k, rc, cc):
    #     rc = int((rc + k - 1) // k) * k
    #     cc = int((cc + k - 1) // k) * k
    #     i = np.arange(0, k, 1).reshape([1, k])
    #     j = np.arange(0, -k, -1).reshape([k, 1])
    #     indx = i + j
    #     indx = (indx + k) % k
    #     m = np.tile(indx, [int(rc // k), int(cc // k)])
    #     offset = np.arange(0, rc * cc)
    #     i = (offset // cc) // k
    #     j = (offset % cc) // k
    #     offset = (i * cc + j * k).reshape([rc, cc])
    #     return m + offset

    def block_indx(self, k, rc, cc):
        rc = int((rc + k - 1) // k) * k
        cc = int((cc + k - 1) // k) * k
        # print('rc,cc',rc,cc)
        i = np.arange(0, k, 1).reshape([k, 1])
        j = np.arange(k - 1, 2 * k - 1, 1).reshape([1, k])
        # print('i',i)
        # print('j',j)
        indx = hankel(i, j)

        m = np.tile(indx, [int(rc // k), int(cc // k)])

        # offset=np.zeros([rc,cc]).astype(np.int)
        start= np.arange(0,rc//k*cc//k*(2*k-1),2*k-1).reshape(rc//k,cc//k)
        start = start.repeat([k], axis=0)
        offset = start.repeat([k], axis=1)
        # for i in range(rc):
        #     for j in range(cc):
        #         offset[i,j] = start[i//k, j//k]

        # print('offset',offset)
        return m + offset


if __name__ == '__main__':
    layer = HankelConv2d(16, 8, 4, 4)